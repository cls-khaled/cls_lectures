# Back-To-Top-Button
Simple back to top (scroll to top) button using HTML5, CSS and JS

Here is a demo: https://godsont.github.io/Back-To-Top-Button/
